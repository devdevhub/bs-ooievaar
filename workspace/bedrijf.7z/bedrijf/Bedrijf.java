
/**
 * Write a description of class Bedrijf here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

   import java.util.*;
   
 public class Bedrijf{
     private ArrayList<afdeling> lijst;
     
     public Bedrijf() {
     lijst = new ArrayList<afdeling>();
    }
    
    public void voegtoe( afdeling lid ) {
     lijst.add(lid);
    }
    public void print() {
      System.out.println( "Afdelingen:" );
      for(afdeling lid : lijst ) {
          System.out.println( "Afdeling: "+lid.toString() );
 
        }

        System.out.println("-------------------------------");
    }
}
        